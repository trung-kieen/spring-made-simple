package com.trung_kieen.bean_play_around;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeanPlayAroundApplicationTests {

	@Test
	void contextLoads() {
	}

}
