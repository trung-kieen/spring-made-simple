```shell
mvn springboot:run
```
